import mysql.connector
from collections import defaultdict
import matplotlib.pyplot as plt

# Database connection configuration
config = {
    'user': 'root',
    'password': 'root',
    'host': 'localhost',
    'unix_socket': '/Applications/MAMP/tmp/mysql/mysql.sock',
    'database': 'LHdbase',
    'raise_on_warnings': True
}

# Establish connection
cnx = mysql.connector.connect(**config)

# Create a cursor object
cursor = cnx.cursor(dictionary=True)

# Execute query to fetch validation and nom_utilisateur data
cursor.execute('SELECT `nom_utilisateur`, `validation` FROM `archive_taches`')

# Fetch all results
results = cursor.fetchall()

# Close the connection
cnx.close()

# Print the results for debugging purposes
for row in results:
    print(row)

#=================================================

# Initialize a dictionary to hold the counts
validation_counts = defaultdict(lambda: {'fait': 0, 'non fait': 0})

# Process the fetched results
for row in results:
    user = row['nom_utilisateur']
    validation = row['validation']
    if validation in ['fait', 'non fait']:
        validation_counts[user][validation] += 1

# Print the processed data for debugging purposes
for user, counts in validation_counts.items():
    print(f'{user}: {counts}')

#=================================================

# Prepare data for plotting
users = list(validation_counts.keys())
fait_counts = [validation_counts[user]['fait'] for user in users]
non_fait_counts = [validation_counts[user]['non fait'] for user in users]

# Set up the bar width and positions
bar_width = 0.25
index = range(len(users))

# Create the bar plots
fig, ax = plt.subplots()
bar1 = ax.bar(index, fait_counts, bar_width, label='Fait')
bar2 = ax.bar([i + bar_width for i in index], non_fait_counts, bar_width, label='Non Fait')

# Add labels, title, and legend
ax.set_xlabel('Users')
ax.set_ylabel('Count')
ax.set_title('Nombre de validations par utilisateur')
ax.set_xticks([i + bar_width / 2 for i in index])
ax.set_xticklabels(users, rotation=0, ha='right')
ax.legend()
plt.show()


#===========================
