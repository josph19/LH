document.addEventListener('DOMContentLoaded', function () {
    // Function to color the options
    function colorOptions() {
        const select = document.querySelector('select[name^="validation"]');
        if (select) {
            Array.from(select.options).forEach(option => {
                switch (option.value) {
                    case 'in progress':
                        option.style.backgroundColor = 'orange';
                        option.style.color = 'white';
                        break;
                    case 'fait':
                        option.style.backgroundColor = 'green';
                        option.style.color = 'white';
                        break;
                    case 'non fait':
                        option.style.backgroundColor = 'red';
                        option.style.color = 'white';
                        break;
                }
            });
        }
    }

    colorOptions();
});
